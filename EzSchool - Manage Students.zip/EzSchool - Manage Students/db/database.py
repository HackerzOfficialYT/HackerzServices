import sqlite3

class EzSchoolDatabase:
    def __init__(self):
        self.conn = sqlite3.connect("ezschool.db")
        self.create_tables()

    def create_tables(self):
        c = self.conn.cursor()
        c.execute('''CREATE TABLE IF NOT EXISTS students (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT, email TEXT, phone TEXT, dob TEXT, guardian TEXT
        )''')
        c.execute('''CREATE TABLE IF NOT EXISTS courses (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT, code TEXT
        )''')
        c.execute('''CREATE TABLE IF NOT EXISTS attendance (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id INTEGER, course_id INTEGER,
            date TEXT, status TEXT
        )''')
        c.execute('''CREATE TABLE IF NOT EXISTS grades (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id INTEGER, course_id INTEGER, grade REAL
        )''')
        c.execute('''CREATE TABLE IF NOT EXISTS fees (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id INTEGER,
            amount REAL,
            status TEXT
        )''')
        c.execute('''CREATE TABLE IF NOT EXISTS timetable (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        day TEXT,
        period INTEGER,
        course_id INTEGER
    )
''')

        self.conn.commit()

    def get_total_students(self):
        cur = self.conn.cursor()
        cur.execute("SELECT COUNT(*) FROM students")
        return cur.fetchone()[0]

    def get_total_courses(self):
        cur = self.conn.cursor()
        cur.execute("SELECT COUNT(*) FROM courses")
        return cur.fetchone()[0]

    def get_total_attendance(self):
        cur = self.conn.cursor()
        cur.execute("SELECT COUNT(*) FROM attendance")
        return cur.fetchone()[0]

    def get_recent_grades(self, limit=5):
        cur = self.conn.cursor()
        cur.execute('''
            SELECT s.name, c.name, g.grade
            FROM grades g
            JOIN students s ON s.id = g.student_id
            JOIN courses c ON c.id = g.course_id
            ORDER BY g.id DESC
            LIMIT ?
        ''', (limit,))
        return cur.fetchall()

    def get_grades(self):
        cur = self.conn.cursor()
        cur.execute('''
            SELECT g.id, s.name, c.name, g.grade
            FROM grades g
            JOIN students s ON g.student_id = s.id
            JOIN courses c ON g.course_id = c.id
            ORDER BY g.id DESC
        ''')
        return cur.fetchall()

    def get_all_students(self):
        cur = self.conn.cursor()
        cur.execute("SELECT id, name FROM students")
        return cur.fetchall()

    def add_fee_payment(self, student_id, amount, status):
        cur = self.conn.cursor()
        cur.execute("INSERT INTO fees (student_id, amount, status) VALUES (?, ?, ?)",
                    (student_id, amount, status))
        self.conn.commit()

    def get_fees(self):
        cur = self.conn.cursor()
        cur.execute('''
            SELECT f.id, s.name, f.amount, f.status
            FROM fees f
            JOIN students s ON s.id = f.student_id
            ORDER BY f.id DESC
        ''')
        return cur.fetchall()

    def delete_fee(self, fee_id):
        cur = self.conn.cursor()
        cur.execute("DELETE FROM fees WHERE id = ?", (fee_id,))
        self.conn.commit()

    def get_performance_report(self):
        cur = self.conn.cursor()
        cur.execute('''
            SELECT s.name, c.name, g.grade
            FROM grades g
            JOIN students s ON s.id = g.student_id
            JOIN courses c ON c.id = g.course_id
            ORDER BY s.name
        ''')
        return cur.fetchall()

    def get_attendance_report(self):
        cur = self.conn.cursor()
        cur.execute('''
            SELECT s.name, c.name, a.date, a.status
            FROM attendance a
            JOIN students s ON s.id = a.student_id
            JOIN courses c ON c.id = a.course_id
            ORDER BY a.date DESC
        ''')
        return cur.fetchall()

    def add_student(self, name, email, phone, dob, guardian):
        cur = self.conn.cursor()
        cur.execute("INSERT INTO students (name, email, phone, dob, guardian) VALUES (?, ?, ?, ?, ?)",
                    (name, email, phone, dob, guardian))
        self.conn.commit()

    def update_student(self, student_id, name, email, phone, dob, guardian):
        cur = self.conn.cursor()
        cur.execute("""
            UPDATE students SET name = ?, email = ?, phone = ?, dob = ?, guardian = ?
            WHERE id = ?
        """, (name, email, phone, dob, guardian, student_id))
        self.conn.commit()

    def delete_student(self, student_id):
        cur = self.conn.cursor()
        cur.execute("DELETE FROM students WHERE id = ?", (student_id,))
        self.conn.commit()

    def get_students(self):
        cur = self.conn.cursor()
        cur.execute("SELECT id, name, email, phone, dob, guardian FROM students ORDER BY id DESC")
        return cur.fetchall()

    def get_courses(self):
        cur = self.conn.cursor()
        cur.execute("SELECT id, name FROM courses")
        return cur.fetchall()

    def get_timetable(self):
        cur = self.conn.cursor()
        cur.execute('''
            SELECT day, period, c.name
            FROM timetable t
            JOIN courses c ON c.id = t.course_id
        ''')
        result = {}
        for day, period, name in cur.fetchall():
            if day not in result:
                result[day] = {}
            result[day][period] = name
        return result

    def add_or_update_slot(self, day, period, course_id):
        cur = self.conn.cursor()
        cur.execute("SELECT id FROM timetable WHERE day = ? AND period = ?", (day, period))
        exists = cur.fetchone()
        if exists:
            cur.execute("UPDATE timetable SET course_id = ? WHERE day = ? AND period = ?", (course_id, day, period))
        else:
            cur.execute("INSERT INTO timetable (day, period, course_id) VALUES (?, ?, ?)", (day, period, course_id))
        self.conn.commit()

    def delete_slot(self, day, period):
        cur = self.conn.cursor()
        cur.execute("DELETE FROM timetable WHERE day = ? AND period = ?", (day, period))
        self.conn.commit()