# ui/timetable.py
from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QLabel, QTableWidget, QTableWidgetItem,
    QComboBox, QPushButton, QHBoxLayout, QFormLayout, QMessageBox, QFrame
)
from db.database import EzSchoolDatabase


class TimetableManagement(QWidget):
    def __init__(self, db, parent=None):
        super().__init__(parent)
        self.db = db
        self.days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"]
        self.periods = 6
        self.selected_day = None
        self.selected_period = None
        self.setup_ui()

    def setup_ui(self):
        self.setStyleSheet("""
            QLabel {
                font-size: 16px;
            }
            QComboBox {
                padding: 8px;
                font-size: 14px;
                border: 1px solid #ccc;
                border-radius: 6px;
            }
            QPushButton {
                padding: 10px 16px;
                font-size: 14px;
                border-radius: 6px;
                background-color: #3498db;
                color: white;
            }
            QPushButton:hover {
                background-color: #2c80b4;
            }
            QTableWidget {
                border: 1px solid #ccc;
                font-size: 13px;
            }
            QHeaderView::section {
                background-color: #3498db;
                color: white;
                font-weight: bold;
                padding: 8px;
                border: none;
            }
        """)

        layout = QVBoxLayout(self)

        title = QLabel("📆 Timetable Management")
        title.setStyleSheet("font-size: 22px; font-weight: bold;")
        layout.addWidget(title)

        # ─── Timetable Table ─────────────────────────────
        self.table = QTableWidget()
        self.table.setRowCount(self.periods)
        self.table.setColumnCount(len(self.days))
        self.table.setHorizontalHeaderLabels(self.days)
        self.table.setVerticalHeaderLabels([f"Period {i+1}" for i in range(self.periods)])
        self.table.setEditTriggers(QTableWidget.NoEditTriggers)
        layout.addWidget(self.table)

        # ─── Form Below ─────────────────────────────────
        form_card = QFrame()
        form_card.setObjectName("card")
        form_layout = QFormLayout(form_card)

        self.day_select = QComboBox()
        self.day_select.addItems(self.days)
        self.period_select = QComboBox()
        self.period_select.addItems([f"{i+1}" for i in range(self.periods)])
        self.course_select = QComboBox()

        form_layout.addRow("Day:", self.day_select)
        form_layout.addRow("Period:", self.period_select)
        form_layout.addRow("Course:", self.course_select)

        btn_layout = QHBoxLayout()
        self.add_btn = QPushButton("➕ Assign Course")
        self.delete_btn = QPushButton("🗑️ Clear Slot")
        btn_layout.addWidget(self.add_btn)
        btn_layout.addWidget(self.delete_btn)
        form_layout.addRow(btn_layout)

        layout.addWidget(form_card)

        # ─── Events ─────────────────────────────────────
        self.add_btn.clicked.connect(self.add_slot)
        self.delete_btn.clicked.connect(self.delete_slot)

        self.load_courses()
        self.load_timetable()

    def load_courses(self):
        self.course_select.clear()
        courses = self.db.get_courses()
        for cid, name in courses:
            self.course_select.addItem(name, cid)

    def load_timetable(self):
        self.table.clearContents()
        data = self.db.get_timetable()
        for col, day in enumerate(self.days):
            for row in range(self.periods):
                name = data.get(day, {}).get(row + 1, "")
                self.table.setItem(row, col, QTableWidgetItem(name))

    def add_slot(self):
        day = self.day_select.currentText()
        period = int(self.period_select.currentText())
        course_id = self.course_select.currentData()

        self.db.add_or_update_slot(day, period, course_id)
        self.load_timetable()
        QMessageBox.information(self, "Saved", f"Course assigned to {day}, Period {period}")

    def delete_slot(self):
        day = self.day_select.currentText()
        period = int(self.period_select.currentText())

        self.db.delete_slot(day, period)
        self.load_timetable()
        QMessageBox.information(self, "Deleted", f"Slot cleared for {day}, Period {period}")
