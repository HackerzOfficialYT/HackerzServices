# ui/attendance.py
from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QLabel, QPushButton, QTableWidget,
    QTableWidgetItem, QHBoxLayout, QFormLayout, QComboBox, QDateEdit,
    QMessageBox, QFrame
)
from PyQt5.QtCore import QDate

class AttendanceManagement(QWidget):
    def __init__(self, db, parent=None):
        super().__init__(parent)
        self.db = db
        self.setup_ui()

    def setup_ui(self):
        self.setStyleSheet("""
            QFrame#card {
                background-color: #ffffff;
                border: 1px solid #dcdcdc;
                border-radius: 8px;
                padding: 15px;
            }
            QLabel {
                font-size: 16px;
            }
            QComboBox, QDateEdit {
                padding: 8px;
                font-size: 14px;
                border: 1px solid #ccc;
                border-radius: 6px;
            }
            QPushButton {
                padding: 10px 16px;
                font-size: 14px;
                border-radius: 6px;
                background-color: #3498db;
                color: white;
            }
            QPushButton:hover {
                background-color: #2c80b4;
            }
            QTableWidget {
                border: 1px solid #ccc;
                font-size: 13px;
            }
            QHeaderView::section {
                background-color: #3498db;
                color: white;
                font-weight: bold;
                padding: 8px;
                border: none;
            }
        """)

        layout = QVBoxLayout(self)

        title = QLabel("📅 Attendance Management")
        title.setStyleSheet("font-size: 22px; font-weight: bold;")
        layout.addWidget(title)

        # ─── Form ───────────────────────────────────────
        form_card = QFrame()
        form_card.setObjectName("card")
        form_layout = QFormLayout(form_card)

        self.course_combo = QComboBox()
        self.student_combo = QComboBox()
        self.date_input = QDateEdit()
        self.date_input.setDate(QDate.currentDate())
        self.status_combo = QComboBox()
        self.status_combo.addItems(["Present", "Absent"])

        form_layout.addRow("Course:", self.course_combo)
        form_layout.addRow("Student:", self.student_combo)
        form_layout.addRow("Date:", self.date_input)
        form_layout.addRow("Status:", self.status_combo)

        button_layout = QHBoxLayout()
        self.add_btn = QPushButton("✅ Mark Attendance")
        self.delete_btn = QPushButton("🗑️ Delete Record")
        button_layout.addWidget(self.add_btn)
        button_layout.addWidget(self.delete_btn)
        form_layout.addRow(button_layout)

        layout.addWidget(form_card)

        # ─── Attendance Table ─────────────────────────────
        self.table = QTableWidget()
        self.table.setColumnCount(4)
        self.table.setHorizontalHeaderLabels(["ID", "Student", "Date", "Status"])
        self.table.setEditTriggers(QTableWidget.NoEditTriggers)
        self.table.setSelectionBehavior(QTableWidget.SelectRows)
        layout.addWidget(self.table)

        # ─── Events ───────────────────────────────────────
        self.add_btn.clicked.connect(self.add_attendance)
        self.delete_btn.clicked.connect(self.delete_attendance)
        self.table.clicked.connect(self.load_to_form)

        self.load_courses()
        self.load_students()
        self.load_attendance_records()

    def load_courses(self):
        # Replace with real DB
        self.course_combo.clear()
        courses = [("Mathematics", "MATH101"), ("Science", "SCI102")]
        for name, code in courses:
            self.course_combo.addItem(f"{name} ({code})")

    def load_students(self):
        self.student_combo.clear()
        students = [("Aarav Mehta", 1), ("Siya Kulkarni", 2)]
        for name, sid in students:
            self.student_combo.addItem(name, sid)

    def load_attendance_records(self):
        records = [
            (1, "Aarav Mehta", "2024-05-10", "Present"),
            (2, "Siya Kulkarni", "2024-05-10", "Absent"),
        ]
        self.table.setRowCount(len(records))
        for row, record in enumerate(records):
            for col, val in enumerate(record):
                self.table.setItem(row, col, QTableWidgetItem(str(val)))

    def add_attendance(self):
        student_name = self.student_combo.currentText()
        course = self.course_combo.currentText()
        date = self.date_input.date().toString("yyyy-MM-dd")
        status = self.status_combo.currentText()

        if not student_name or not course:
            QMessageBox.warning(self, "Error", "Please select a valid student and course.")
            return

        row = self.table.rowCount()
        self.table.insertRow(row)
        self.table.setItem(row, 0, QTableWidgetItem(str(row + 1)))
        self.table.setItem(row, 1, QTableWidgetItem(student_name))
        self.table.setItem(row, 2, QTableWidgetItem(date))
        self.table.setItem(row, 3, QTableWidgetItem(status))

        QMessageBox.information(self, "Success", "Attendance marked successfully.")

    def delete_attendance(self):
        row = self.table.currentRow()
        if row < 0:
            QMessageBox.warning(self, "Error", "Select a record to delete.")
            return

        self.table.removeRow(row)
        QMessageBox.information(self, "Deleted", "Attendance record deleted.")

    def load_to_form(self):
        row = self.table.currentRow()
        if row >= 0:
            student = self.table.item(row, 1).text()
            date = self.table.item(row, 2).text()
            status = self.table.item(row, 3).text()

            self.student_combo.setCurrentText(student)
            self.date_input.setDate(QDate.fromString(date, "yyyy-MM-dd"))
            self.status_combo.setCurrentText(status)
