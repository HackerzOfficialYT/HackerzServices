# ui/reports.py
from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QLabel, QPushButton, QTableWidget,
    QTableWidgetItem, QHBoxLayout, QFrame, QFileDialog, QMessageBox
)
import csv
from db.database import EzSchoolDatabase


class ReportViewer(QWidget):
    def __init__(self, db, parent=None):
        super().__init__(parent)
        self.db = db
        self.current_report_type = None
        self.setup_ui()

    def setup_ui(self):
        self.setStyleSheet("""
            QLabel {
                font-size: 16px;
            }
            QPushButton {
                padding: 10px 16px;
                font-size: 14px;
                border-radius: 6px;
                background-color: #3498db;
                color: white;
            }
            QPushButton:hover {
                background-color: #2c80b4;
            }
            QFrame#card {
                background-color: #ffffff;
                border: 1px solid #dcdcdc;
                border-radius: 8px;
                padding: 15px;
            }
            QTableWidget {
                border: 1px solid #ccc;
                font-size: 13px;
            }
            QHeaderView::section {
                background-color: #3498db;
                color: white;
                font-weight: bold;
                padding: 8px;
                border: none;
            }
        """)

        layout = QVBoxLayout(self)

        title = QLabel("📊 Reports & Export")
        title.setStyleSheet("font-size: 22px; font-weight: bold;")
        layout.addWidget(title)

        # ─── Buttons ─────────────────────────────
        btn_frame = QFrame()
        btn_frame.setObjectName("card")
        btn_layout = QHBoxLayout(btn_frame)

        self.performance_btn = QPushButton("📈 Performance Report")
        self.attendance_btn = QPushButton("📅 Attendance Report")
        self.export_btn = QPushButton("📤 Export to CSV")

        btn_layout.addWidget(self.performance_btn)
        btn_layout.addWidget(self.attendance_btn)
        btn_layout.addWidget(self.export_btn)

        layout.addWidget(btn_frame)

        # ─── Table ───────────────────────────────
        self.table = QTableWidget()
        self.table.setEditTriggers(QTableWidget.NoEditTriggers)
        layout.addWidget(self.table)

        # ─── Event Bindings ───────────────────────
        self.performance_btn.clicked.connect(self.load_performance_report)
        self.attendance_btn.clicked.connect(self.load_attendance_report)
        self.export_btn.clicked.connect(self.export_to_csv)

    def load_performance_report(self):
        self.current_report_type = "performance"
        data = self.db.get_performance_report()
        headers = ["Student", "Course", "Grade"]
        self.populate_table(data, headers)

    def load_attendance_report(self):
        self.current_report_type = "attendance"
        data = self.db.get_attendance_report()
        headers = ["Student", "Course", "Date", "Status"]
        self.populate_table(data, headers)

    def populate_table(self, data, headers):
        self.table.clear()
        self.table.setColumnCount(len(headers))
        self.table.setHorizontalHeaderLabels(headers)
        self.table.setRowCount(len(data))

        for row, record in enumerate(data):
            for col, value in enumerate(record):
                self.table.setItem(row, col, QTableWidgetItem(str(value)))

    def export_to_csv(self):
        if self.table.rowCount() == 0:
            QMessageBox.warning(self, "Error", "No data to export.")
            return

        path, _ = QFileDialog.getSaveFileName(self, "Save Report", "", "CSV Files (*.csv)")
        if path:
            with open(path, mode='w', newline='', encoding='utf-8') as file:
                writer = csv.writer(file)
                headers = [self.table.horizontalHeaderItem(i).text() for i in range(self.table.columnCount())]
                writer.writerow(headers)

                for row in range(self.table.rowCount()):
                    row_data = [self.table.item(row, col).text() for col in range(self.table.columnCount())]
                    writer.writerow(row_data)

            QMessageBox.information(self, "Exported", "Report exported successfully.")
