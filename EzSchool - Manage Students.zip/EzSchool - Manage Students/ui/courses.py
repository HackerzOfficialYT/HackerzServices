from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QLabel, QLineEdit, QPushButton,
    QTableWidget, QTableWidgetItem, QHBoxLayout, QFormLayout,
    QMessageBox, QFrame
)
from PyQt5.QtCore import Qt

class CourseManagement(QWidget):
    def __init__(self, db, parent=None):
        super().__init__(parent)
        self.db = db
        self.setup_ui()

    def setup_ui(self):
        self.setStyleSheet("""
            QFrame#card {
                background-color: #ffffff;
                border: 1px solid #dcdcdc;
                border-radius: 8px;
                padding: 15px;
            }
            QLabel {
                font-size: 16px;
            }
            QLineEdit {
                padding: 8px;
                font-size: 14px;
                border: 1px solid #ccc;
                border-radius: 6px;
            }
            QPushButton {
                padding: 10px 16px;
                font-size: 14px;
                border-radius: 6px;
                background-color: #3498db;
                color: white;
            }
            QPushButton:hover {
                background-color: #2c80b4;
            }
            QTableWidget {
                border: 1px solid #ccc;
                font-size: 13px;
            }
            QHeaderView::section {
                background-color: #3498db;
                color: white;
                font-weight: bold;
                padding: 8px;
                border: none;
            }
        """)

        layout = QVBoxLayout(self)

        header = QLabel("📚 Course Management")
        header.setStyleSheet("font-size: 22px; font-weight: bold;")
        layout.addWidget(header)

        # ─── Form Card ───────────────────────────────
        form_card = QFrame()
        form_card.setObjectName("card")
        form_layout = QFormLayout(form_card)

        self.name_input = QLineEdit()
        self.code_input = QLineEdit()
        form_layout.addRow("Course Name:", self.name_input)
        form_layout.addRow("Course Code:", self.code_input)

        btn_layout = QHBoxLayout()
        self.add_btn = QPushButton("➕ Add Course")
        self.update_btn = QPushButton("✏️ Update")
        self.delete_btn = QPushButton("🗑️ Delete")
        btn_layout.addWidget(self.add_btn)
        btn_layout.addWidget(self.update_btn)
        btn_layout.addWidget(self.delete_btn)
        form_layout.addRow(btn_layout)

        layout.addWidget(form_card)

        # ─── Course Table ───────────────────────────────
        self.table = QTableWidget()
        self.table.setColumnCount(3)
        self.table.setHorizontalHeaderLabels(["ID", "Course Name", "Course Code"])
        self.table.setEditTriggers(QTableWidget.NoEditTriggers)
        self.table.setSelectionBehavior(QTableWidget.SelectRows)
        layout.addWidget(self.table)

        # ─── Bind Buttons ───────────────────────────────
        self.add_btn.clicked.connect(self.add_course)
        self.update_btn.clicked.connect(self.update_course)
        self.delete_btn.clicked.connect(self.delete_course)
        self.table.clicked.connect(self.load_to_form)

        self.load_courses()

    def load_courses(self):
        # Replace with real DB later
        data = [
            (1, "Mathematics", "MATH101"),
            (2, "Computer Science", "CS102")
        ]
        self.table.setRowCount(len(data))
        for row, record in enumerate(data):
            for col, item in enumerate(record):
                self.table.setItem(row, col, QTableWidgetItem(str(item)))

    def add_course(self):
        name = self.name_input.text().strip()
        code = self.code_input.text().strip()

        if not name or not code:
            QMessageBox.warning(self, "Error", "Course name and code are required.")
            return

        row = self.table.rowCount()
        self.table.insertRow(row)
        self.table.setItem(row, 0, QTableWidgetItem(str(row + 1)))
        self.table.setItem(row, 1, QTableWidgetItem(name))
        self.table.setItem(row, 2, QTableWidgetItem(code))

        self.name_input.clear()
        self.code_input.clear()

        QMessageBox.information(self, "Success", "Course added successfully.")

    def update_course(self):
        row = self.table.currentRow()
        if row < 0:
            QMessageBox.warning(self, "Error", "Select a course to update.")
            return

        name = self.name_input.text().strip()
        code = self.code_input.text().strip()

        self.table.setItem(row, 1, QTableWidgetItem(name))
        self.table.setItem(row, 2, QTableWidgetItem(code))

        QMessageBox.information(self, "Updated", "Course information updated.")

    def delete_course(self):
        row = self.table.currentRow()
        if row < 0:
            QMessageBox.warning(self, "Error", "Select a course to delete.")
            return

        self.table.removeRow(row)
        QMessageBox.information(self, "Deleted", "Course deleted.")

    def load_to_form(self):
        row = self.table.currentRow()
        if row >= 0:
            self.name_input.setText(self.table.item(row, 1).text())
            self.code_input.setText(self.table.item(row, 2).text())
