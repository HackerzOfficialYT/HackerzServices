# ui/grades.py
from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QLabel, QLineEdit, QPushButton,
    QTableWidget, QTableWidgetItem, QHBoxLayout, QFormLayout,
    QMessageBox, QComboBox, QFrame
)
from db.database import EzSchoolDatabase

class GradeManagement(QWidget):
    def __init__(self, db, parent=None):
        super().__init__(parent)
        self.db = db
        self.setup_ui()

    def setup_ui(self):
        self.setStyleSheet("""
            QFrame#card {
                background-color: #ffffff;
                border: 1px solid #dcdcdc;
                border-radius: 8px;
                padding: 15px;
            }
            QLabel {
                font-size: 16px;
            }
            QComboBox, QLineEdit {
                padding: 8px;
                font-size: 14px;
                border: 1px solid #ccc;
                border-radius: 6px;
            }
            QPushButton {
                padding: 10px 16px;
                font-size: 14px;
                border-radius: 6px;
                background-color: #3498db;
                color: white;
            }
            QPushButton:hover {
                background-color: #2c80b4;
            }
            QTableWidget {
                border: 1px solid #ccc;
                font-size: 13px;
            }
            QHeaderView::section {
                background-color: #3498db;
                color: white;
                font-weight: bold;
                padding: 8px;
                border: none;
            }
        """)

        layout = QVBoxLayout(self)

        title = QLabel("🎓 Grade Management")
        title.setStyleSheet("font-size: 22px; font-weight: bold;")
        layout.addWidget(title)

        # ─── Form ───────────────────────────────
        form_card = QFrame()
        form_card.setObjectName("card")
        form_layout = QFormLayout(form_card)

        self.student_combo = QComboBox()
        self.course_combo = QComboBox()
        self.grade_input = QLineEdit()

        form_layout.addRow("Student:", self.student_combo)
        form_layout.addRow("Course:", self.course_combo)
        form_layout.addRow("Grade:", self.grade_input)

        btn_layout = QHBoxLayout()
        self.add_btn = QPushButton("➕ Add Grade")
        self.delete_btn = QPushButton("🗑️ Delete")
        btn_layout.addWidget(self.add_btn)
        btn_layout.addWidget(self.delete_btn)
        form_layout.addRow(btn_layout)

        layout.addWidget(form_card)

        # ─── Grade Table ───────────────────────────────
        self.table = QTableWidget()
        self.table.setColumnCount(4)
        self.table.setHorizontalHeaderLabels(["ID", "Student", "Course", "Grade"])
        self.table.setEditTriggers(QTableWidget.NoEditTriggers)
        self.table.setSelectionBehavior(QTableWidget.SelectRows)
        layout.addWidget(self.table)

        # ─── Event Bindings ────────────────────────────
        self.add_btn.clicked.connect(self.add_grade)
        self.delete_btn.clicked.connect(self.delete_grade)

        self.load_students()
        self.load_courses()
        self.load_grades()

    def load_students(self):
        self.student_combo.clear()
        for sid, name in self.db.get_all_students():
            self.student_combo.addItem(name, sid)

    def load_courses(self):
        self.course_combo.clear()
        cur = self.db.conn.cursor()
        cur.execute("SELECT id, name FROM courses")
        for cid, name in cur.fetchall():
            self.course_combo.addItem(name, cid)

    def load_grades(self):
        data = self.db.get_grades()
        self.table.setRowCount(len(data))
        for row, (gid, student, course, grade) in enumerate(data):
            self.table.setItem(row, 0, QTableWidgetItem(str(gid)))
            self.table.setItem(row, 1, QTableWidgetItem(student))
            self.table.setItem(row, 2, QTableWidgetItem(course))
            self.table.setItem(row, 3, QTableWidgetItem(str(grade)))

    def add_grade(self):
        student_id = self.student_combo.currentData()
        course_id = self.course_combo.currentData()
        grade_text = self.grade_input.text().strip()

        try:
            grade = float(grade_text)
        except ValueError:
            QMessageBox.warning(self, "Error", "Grade must be a number.")
            return

        self.db.add_grade(student_id, course_id, grade)
        self.grade_input.clear()
        self.load_grades()
        QMessageBox.information(self, "Success", "Grade added successfully.")

    def delete_grade(self):
        row = self.table.currentRow()
        if row < 0:
            QMessageBox.warning(self, "Error", "Select a grade to delete.")
            return

        grade_id = int(self.table.item(row, 0).text())
        self.db.delete_grade(grade_id)
        self.load_grades()
        QMessageBox.information(self, "Deleted", "Grade deleted.")
