from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QLabel, QLineEdit, QPushButton,
    QTableWidget, QTableWidgetItem, QHBoxLayout, QFormLayout,
    QMessageBox, QFrame
)
from db.database import EzSchoolDatabase


class StudentManagement(QWidget):
    def __init__(self, db, parent=None):
        super().__init__(parent)
        self.db = db
        self.setup_ui()

    def setup_ui(self):
        self.setStyleSheet("""
            QFrame#card {
                background-color: #ffffff;
                border: 1px solid #dcdcdc;
                border-radius: 8px;
                padding: 15px;
            }
            QLabel {
                font-size: 16px;
            }
            QLineEdit {
                padding: 8px;
                font-size: 14px;
                border: 1px solid #ccc;
                border-radius: 6px;
            }
            QPushButton {
                padding: 10px 16px;
                font-size: 14px;
                border-radius: 6px;
                background-color: #3498db;
                color: white;
            }
            QPushButton:hover {
                background-color: #2c80b4;
            }
            QTableWidget {
                border: 1px solid #ccc;
                font-size: 13px;
            }
            QHeaderView::section {
                background-color: #3498db;
                color: white;
                font-weight: bold;
                padding: 8px;
                border: none;
            }
        """)

        layout = QVBoxLayout(self)

        title = QLabel("👩‍🎓 Student Management")
        title.setStyleSheet("font-size: 22px; font-weight: bold;")
        layout.addWidget(title)

        # ─── Form ───────────────────────────────────────
        form_card = QFrame()
        form_card.setObjectName("card")
        form_layout = QFormLayout(form_card)

        self.name_input = QLineEdit()
        self.email_input = QLineEdit()
        self.phone_input = QLineEdit()
        self.dob_input = QLineEdit()
        self.guardian_input = QLineEdit()

        form_layout.addRow("Full Name:", self.name_input)
        form_layout.addRow("Email:", self.email_input)
        form_layout.addRow("Phone:", self.phone_input)
        form_layout.addRow("DOB (YYYY-MM-DD):", self.dob_input)
        form_layout.addRow("Guardian:", self.guardian_input)

        btn_layout = QHBoxLayout()
        self.add_btn = QPushButton("➕ Add")
        self.update_btn = QPushButton("✏️ Update")
        self.delete_btn = QPushButton("🗑️ Delete")
        btn_layout.addWidget(self.add_btn)
        btn_layout.addWidget(self.update_btn)
        btn_layout.addWidget(self.delete_btn)
        form_layout.addRow(btn_layout)

        layout.addWidget(form_card)

        # ─── Table ──────────────────────────────────────
        self.table = QTableWidget()
        self.table.setColumnCount(6)
        self.table.setHorizontalHeaderLabels(["ID", "Name", "Email", "Phone", "DOB", "Guardian"])
        self.table.setEditTriggers(QTableWidget.NoEditTriggers)
        self.table.setSelectionBehavior(QTableWidget.SelectRows)
        layout.addWidget(self.table)

        # ─── Events ─────────────────────────────────────
        self.add_btn.clicked.connect(self.add_student)
        self.update_btn.clicked.connect(self.update_student)
        self.delete_btn.clicked.connect(self.delete_student)
        self.table.clicked.connect(self.load_selected_student)

        self.load_students()

    def load_students(self):
        students = self.db.get_students()
        self.table.setRowCount(len(students))
        for row, (sid, name, email, phone, dob, guardian) in enumerate(students):
            self.table.setItem(row, 0, QTableWidgetItem(str(sid)))
            self.table.setItem(row, 1, QTableWidgetItem(name))
            self.table.setItem(row, 2, QTableWidgetItem(email))
            self.table.setItem(row, 3, QTableWidgetItem(phone))
            self.table.setItem(row, 4, QTableWidgetItem(dob))
            self.table.setItem(row, 5, QTableWidgetItem(guardian))

    def add_student(self):
        name = self.name_input.text().strip()
        email = self.email_input.text().strip()
        phone = self.phone_input.text().strip()
        dob = self.dob_input.text().strip()
        guardian = self.guardian_input.text().strip()

        if not name or not email:
            QMessageBox.warning(self, "Error", "Name and Email are required.")
            return

        self.db.add_student(name, email, phone, dob, guardian)
        self.clear_form()
        self.load_students()
        QMessageBox.information(self, "Success", "Student added successfully.")

    def update_student(self):
        if self.selected_id is None:
            QMessageBox.warning(self, "Error", "Select a student to update.")
            return

        name = self.name_input.text().strip()
        email = self.email_input.text().strip()
        phone = self.phone_input.text().strip()
        dob = self.dob_input.text().strip()
        guardian = self.guardian_input.text().strip()

        self.db.update_student(self.selected_id, name, email, phone, dob, guardian)
        self.clear_form()
        self.load_students()
        QMessageBox.information(self, "Updated", "Student updated.")

    def delete_student(self):
        if self.selected_id is None:
            QMessageBox.warning(self, "Error", "Select a student to delete.")
            return

        self.db.delete_student(self.selected_id)
        self.clear_form()
        self.load_students()
        QMessageBox.information(self, "Deleted", "Student deleted.")

    def load_selected_student(self):
        row = self.table.currentRow()
        if row >= 0:
            self.selected_id = int(self.table.item(row, 0).text())
            self.name_input.setText(self.table.item(row, 1).text())
            self.email_input.setText(self.table.item(row, 2).text())
            self.phone_input.setText(self.table.item(row, 3).text())
            self.dob_input.setText(self.table.item(row, 4).text())
            self.guardian_input.setText(self.table.item(row, 5).text())

    def clear_form(self):
        self.selected_id = None
        self.name_input.clear()
        self.email_input.clear()
        self.phone_input.clear()
        self.dob_input.clear()
        self.guardian_input.clear()
