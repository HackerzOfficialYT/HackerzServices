# ui/fees.py
from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QLabel, QLineEdit, QPushButton,
    QTableWidget, QTableWidgetItem, QHBoxLayout, QFormLayout,
    QMessageBox, QComboBox, QFrame
)
from db.database import EzSchoolDatabase


class FeeManagement(QWidget):
    def __init__(self, db, parent=None):
        super().__init__(parent)
        self.db = db
        self.setup_ui()

    def setup_ui(self):
        self.setStyleSheet("""
            QFrame#card {
                background-color: #ffffff;
                border: 1px solid #dcdcdc;
                border-radius: 8px;
                padding: 15px;
            }
            QLabel {
                font-size: 16px;
            }
            QComboBox, QLineEdit {
                padding: 8px;
                font-size: 14px;
                border: 1px solid #ccc;
                border-radius: 6px;
            }
            QPushButton {
                padding: 10px 16px;
                font-size: 14px;
                border-radius: 6px;
                background-color: #3498db;
                color: white;
            }
            QPushButton:hover {
                background-color: #2c80b4;
            }
            QTableWidget {
                border: 1px solid #ccc;
                font-size: 13px;
            }
            QHeaderView::section {
                background-color: #3498db;
                color: white;
                font-weight: bold;
                padding: 8px;
                border: none;
            }
        """)

        layout = QVBoxLayout(self)

        title = QLabel("💸 Fee Management")
        title.setStyleSheet("font-size: 22px; font-weight: bold;")
        layout.addWidget(title)

        # ─── Form ───────────────────────────────────────
        form_card = QFrame()
        form_card.setObjectName("card")
        form_layout = QFormLayout(form_card)

        self.student_combo = QComboBox()
        self.amount_input = QLineEdit()
        self.status_combo = QComboBox()
        self.status_combo.addItems(["Paid", "Pending"])

        form_layout.addRow("Student:", self.student_combo)
        form_layout.addRow("Amount:", self.amount_input)
        form_layout.addRow("Status:", self.status_combo)

        btn_layout = QHBoxLayout()
        self.add_btn = QPushButton("➕ Add Payment")
        self.delete_btn = QPushButton("🗑️ Delete")
        btn_layout.addWidget(self.add_btn)
        btn_layout.addWidget(self.delete_btn)
        form_layout.addRow(btn_layout)

        layout.addWidget(form_card)

        # ─── Table ──────────────────────────────────────
        self.table = QTableWidget()
        self.table.setColumnCount(4)
        self.table.setHorizontalHeaderLabels(["ID", "Student", "Amount", "Status"])
        self.table.setEditTriggers(QTableWidget.NoEditTriggers)
        self.table.setSelectionBehavior(QTableWidget.SelectRows)
        layout.addWidget(self.table)

        # ─── Events ─────────────────────────────────────
        self.add_btn.clicked.connect(self.add_payment)
        self.delete_btn.clicked.connect(self.delete_payment)

        self.load_students()
        self.load_fees()

    def load_students(self):
        self.student_combo.clear()
        students = self.db.get_all_students()
        for sid, name in students:
            self.student_combo.addItem(name, sid)

    def load_fees(self):
        data = self.db.get_fees()
        self.table.setRowCount(len(data))
        for row, (fid, name, amount, status) in enumerate(data):
            self.table.setItem(row, 0, QTableWidgetItem(str(fid)))
            self.table.setItem(row, 1, QTableWidgetItem(name))
            self.table.setItem(row, 2, QTableWidgetItem(f"{amount:.2f}"))
            self.table.setItem(row, 3, QTableWidgetItem(status))

    def add_payment(self):
        student_id = self.student_combo.currentData()
        amount_text = self.amount_input.text().strip()
        status = self.status_combo.currentText()

        try:
            amount = float(amount_text)
        except ValueError:
            QMessageBox.warning(self, "Error", "Invalid amount entered.")
            return

        self.db.add_fee_payment(student_id, amount, status)
        self.amount_input.clear()
        self.load_fees()
        QMessageBox.information(self, "Success", "Payment added.")

    def delete_payment(self):
        row = self.table.currentRow()
        if row < 0:
            QMessageBox.warning(self, "Error", "Select a payment record to delete.")
            return

        fee_id = int(self.table.item(row, 0).text())
        self.db.delete_fee(fee_id)
        self.load_fees()
        QMessageBox.information(self, "Deleted", "Payment record deleted.")
