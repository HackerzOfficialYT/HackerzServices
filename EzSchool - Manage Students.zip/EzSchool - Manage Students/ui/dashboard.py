from PyQt5.QtWidgets import QWidget
from PyQt5.QtWidgets import QWidget, QVBoxLayout, QLabel, QFrame, QHBoxLayout, QTableWidget, QTableWidgetItem
from db.database import EzSchoolDatabase  # only if needed

class DashboardWindow(QWidget):
    def __init__(self, db, parent=None):
        super().__init__(parent)
        self.db = db
        self.setup_ui()

    def setup_ui(self):
        self.setStyleSheet("""
            QLabel#header {
                font-size: 22px;
                font-weight: bold;
            }
            QLabel#stat {
                font-size: 18px;
                font-weight: bold;
                color: #3498db;
            }
            QFrame#card {
                background-color: #ffffff;
                border: 1px solid #dcdcdc;
                border-radius: 8px;
                padding: 15px;
            }
            QTableWidget {
                border: 1px solid #ccc;
                font-size: 13px;
            }
            QHeaderView::section {
                background-color: #3498db;
                color: white;
                font-weight: bold;
                padding: 8px;
                border: none;
            }
        """)

        layout = QVBoxLayout(self)

        header = QLabel("🏠 Dashboard")
        header.setObjectName("header")
        layout.addWidget(header)

        stats_frame = QFrame()
        stats_frame.setObjectName("card")
        stats_layout = QHBoxLayout(stats_frame)

        self.student_stat = QLabel()
        self.course_stat = QLabel()
        self.attendance_stat = QLabel()

        for stat in [self.student_stat, self.course_stat, self.attendance_stat]:
            stat.setObjectName("stat")
            stats_layout.addWidget(stat)

        layout.addWidget(stats_frame)

        self.table_title = QLabel("📊 Recent Grades")
        self.table_title.setStyleSheet("font-size: 18px; font-weight: bold;")
        layout.addWidget(self.table_title)

        self.table = QTableWidget()
        self.table.setColumnCount(3)
        self.table.setHorizontalHeaderLabels(["Student", "Course", "Grade"])
        self.table.setEditTriggers(QTableWidget.NoEditTriggers)
        layout.addWidget(self.table)

        self.refresh_dashboard()

    def refresh_dashboard(self):
        students = self.db.get_total_students()
        courses = self.db.get_total_courses()
        attendance = self.db.get_total_attendance()
        grades = self.db.get_recent_grades()

        self.student_stat.setText(f"👩‍🎓 Students: {students}")
        self.course_stat.setText(f"📚 Courses: {courses}")
        self.attendance_stat.setText(f"📝 Attendance: {attendance}")

        self.table.setRowCount(len(grades))
        for row, (student, course, grade) in enumerate(grades):
            self.table.setItem(row, 0, QTableWidgetItem(student))
            self.table.setItem(row, 1, QTableWidgetItem(course))
            self.table.setItem(row, 2, QTableWidgetItem(str(grade)))
