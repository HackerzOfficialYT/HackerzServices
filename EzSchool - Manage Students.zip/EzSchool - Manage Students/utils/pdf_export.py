# utils/pdf_export.py

from PyQt5.QtWidgets import QFileDialog, QMessageBox
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from reportlab.lib import colors
from reportlab.platypus import Table, TableStyle, SimpleDocTemplate


def export_table_to_pdf(table_widget, parent_window=None, title="EzSchool Report"):
    if table_widget.rowCount() == 0:
        QMessageBox.warning(parent_window, "Export Failed", "No data to export.")
        return

    path, _ = QFileDialog.getSaveFileName(
        parent_window,
        "Save PDF Report",
        "",
        "PDF Files (*.pdf)"
    )

    if not path:
        return  # User canceled

    try:
        # Collect table data
        headers = [table_widget.horizontalHeaderItem(i).text()
                   for i in range(table_widget.columnCount())]

        data = [headers]

        for row in range(table_widget.rowCount()):
            row_data = []
            for col in range(table_widget.columnCount()):
                item = table_widget.item(row, col)
                row_data.append(item.text() if item else "")
            data.append(row_data)

        # Create PDF
        pdf = SimpleDocTemplate(path, pagesize=A4)
        table = Table(data, repeatRows=1)

        style = TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor("#3498db")),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 11),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 10),
            ('GRID', (0, 0), (-1, -1), 0.5, colors.grey),
        ])
        table.setStyle(style)

        pdf.build([table])

        QMessageBox.information(parent_window, "Exported", "PDF exported successfully.")
    except Exception as e:
        QMessageBox.critical(parent_window, "Error", f"Failed to export PDF:\n{str(e)}")
