# utils/backup.py
import os
import shutil
import datetime
from PyQt5.QtWidgets import QFileDialog, QMessageBox


def ensure_backup_dir(path="resources/backups"):
    if not os.path.exists(path):
        os.makedirs(path)
    return path


def create_backup(db_path="ezschool.db", backup_dir="resources/backups"):
    ensure_backup_dir(backup_dir)
    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_filename = f"backup_{timestamp}.bak"
    backup_path = os.path.join(backup_dir, backup_filename)

    try:
        shutil.copy(db_path, backup_path)
        return backup_path
    except Exception as e:
        return str(e)


def restore_backup(app_window, db_path="ezschool.db"):
    file_path, _ = QFileDialog.getOpenFileName(
        app_window,
        "Select Backup File",
        "resources/backups/",
        "Backup Files (*.bak)"
    )

    if file_path:
        try:
            shutil.copy(file_path, db_path)
            QMessageBox.information(app_window, "Success", "Database restored successfully.")
        except Exception as e:
            QMessageBox.critical(app_window, "Error", f"Failed to restore backup:\n{e}")
