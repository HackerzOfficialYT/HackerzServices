# utils/csv_export.py

import csv
from PyQt5.QtWidgets import QFileDialog, QMessageBox


def export_table_to_csv(table_widget, parent_window=None):
    """
    Export the contents of a QTableWidget to a CSV file.

    :param table_widget: QTableWidget instance to export
    :param parent_window: Parent QWidget (for dialogs)
    """
    if table_widget.rowCount() == 0:
        QMessageBox.warning(parent_window, "Export Failed", "No data available to export.")
        return

    path, _ = QFileDialog.getSaveFileName(
        parent_window,
        "Export as CSV",
        "",
        "CSV Files (*.csv)"
    )

    if not path:
        return  # User cancelled

    try:
        with open(path, mode='w', newline='', encoding='utf-8') as file:
            writer = csv.writer(file)

            # Write headers
            headers = [table_widget.horizontalHeaderItem(i).text()
                       for i in range(table_widget.columnCount())]
            writer.writerow(headers)

            # Write row data
            for row in range(table_widget.rowCount()):
                row_data = []
                for col in range(table_widget.columnCount()):
                    item = table_widget.item(row, col)
                    row_data.append(item.text() if item else "")
                writer.writerow(row_data)

        QMessageBox.information(parent_window, "Success", "CSV exported successfully.")
    except Exception as e:
        QMessageBox.critical(parent_window, "Error", f"Failed to export CSV:\n{str(e)}")
