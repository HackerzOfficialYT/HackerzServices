# utils/validators.py

import re
from datetime import datetime


def is_valid_email(email):
    """
    Validates an email address using a simple regex.
    """
    pattern = r'^[\w\.-]+@[\w\.-]+\.\w+$'
    return bool(re.match(pattern, email))


def is_valid_phone(phone):
    """
    Validates a phone number (Indian standard: 10 digits).
    """
    return phone.isdigit() and len(phone) == 10


def is_valid_date(date_str, format="%Y-%m-%d"):
    """
    Checks if the given date string matches the expected format.
    """
    try:
        datetime.strptime(date_str, format)
        return True
    except ValueError:
        return False


def is_valid_grade(grade):
    """
    Ensures the grade is a number between 0 and 100.
    """
    try:
        value = float(grade)
        return 0 <= value <= 100
    except ValueError:
        return False


def is_not_empty(*fields):
    """
    Ensures none of the provided fields are empty.
    """
    return all(field.strip() for field in fields)
