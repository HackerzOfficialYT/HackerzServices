# utils/config.py

import os

# 📁 Base app path
BASE_DIR = os.path.abspath(os.path.dirname(__file__ + "/.."))

# 💾 Main database file
DATABASE_PATH = os.path.join(BASE_DIR, "ezschool.db")

# 📁 Backup folder
BACKUP_DIR = os.path.join(BASE_DIR, "resources", "backups")

# 📁 Export/report folder
EXPORT_DIR = os.path.join(BASE_DIR, "resources", "reports")

# 🌐 Application info
APP_NAME = "EzSchool Pro"
APP_VERSION = "1.0.0"
DEVELOPER = "Ariverse"

# 🎨 UI theme options (for future use)
DEFAULT_THEME = "light"  # Options: "light", "dark"

# 🐞 Debugging mode
DEBUG = False
