# main.py

import sys
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QStackedWidget, QWidget,
    QVBoxLayout, QPushButton, QHBoxLayout, QFrame
)

# Database
from db.database import EzSchoolDatabase

# UI Modules
from ui.dashboard import DashboardWindow
from ui.students import StudentManagement
from ui.courses import CourseManagement
from ui.attendance import AttendanceManagement
from ui.grades import GradeManagement
from ui.fees import FeeManagement
from ui.reports import ReportViewer
from ui.timetable import TimetableManagement

class MainApp(QMainWindow):
    def __init__(self, db):
        super().__init__()
        self.setWindowTitle("EzSchool Pro - Admin Panel")
        self.setGeometry(100, 100, 1280, 800)
        self.db = db

        # Central widget layout
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        main_layout = QHBoxLayout(central_widget)

        # Sidebar
        self.sidebar = QFrame()
        self.sidebar.setFixedWidth(200)
        sidebar_layout = QVBoxLayout(self.sidebar)
        sidebar_layout.setSpacing(10)

        # Navigation buttons
        buttons = [
            ("🏠 Dashboard", self.load_dashboard),
            ("👩‍🎓 Students", self.load_students),
            ("📚 Courses", self.load_courses),
            ("📅 Attendance", self.load_attendance),
            ("🎓 Grades", self.load_grades),
            ("💸 Fees", self.load_fees),
            ("📊 Reports", self.load_reports),
            ("📆 Timetable", self.load_timetable)
        ]

        for label, func in buttons:
            btn = QPushButton(label)
            btn.clicked.connect(func)
            sidebar_layout.addWidget(btn)

        sidebar_layout.addStretch()
        main_layout.addWidget(self.sidebar)

        # Stacked widget for screens
        self.stack = QStackedWidget()
        main_layout.addWidget(self.stack)

        # Initialize all screens with DB and parent
        self.dashboard = DashboardWindow(self.db, self)
        self.students = StudentManagement(self.db, self)
        self.courses = CourseManagement(self.db, self)
        self.attendance = AttendanceManagement(self.db, self)
        self.grades = GradeManagement(self.db, self)
        self.fees = FeeManagement(self.db, self)
        self.reports = ReportViewer(self.db, self)
        self.timetable = TimetableManagement(self.db, self)

        # Add screens to stack
        self.stack.addWidget(self.dashboard)    # index 0
        self.stack.addWidget(self.students)     # index 1
        self.stack.addWidget(self.courses)      # index 2
        self.stack.addWidget(self.attendance)   # index 3
        self.stack.addWidget(self.grades)       # index 4
        self.stack.addWidget(self.fees)         # index 5
        self.stack.addWidget(self.reports)      # index 6
        self.stack.addWidget(self.timetable)    # index 7

        self.stack.setCurrentIndex(0)

    # Navigation Functions
    def load_dashboard(self): self.stack.setCurrentIndex(0)
    def load_students(self): self.stack.setCurrentIndex(1)
    def load_courses(self): self.stack.setCurrentIndex(2)
    def load_attendance(self): self.stack.setCurrentIndex(3)
    def load_grades(self): self.stack.setCurrentIndex(4)
    def load_fees(self): self.stack.setCurrentIndex(5)
    def load_reports(self): self.stack.setCurrentIndex(6)
    def load_timetable(self): self.stack.setCurrentIndex(7)

if __name__ == '__main__':
    app = QApplication(sys.argv)

    # Load global stylesheet if exists
    try:
        with open("styles.qss", "r") as f:
            app.setStyleSheet(f.read())
    except FileNotFoundError:
        pass  # Optional

    db = EzSchoolDatabase()
    window = MainApp(db)
    window.show()

    sys.exit(app.exec_())
